let moshinBozor = [
    {
        name: 'malibu',
        price: 24000
    },
    {
        name: 'Matiz',
        price: 3500
    },
    {
        name: 'tahoe',
        price: 80000
    },
    {
        name: 'Nexia',
        price: 10000
    },
    {
        name: 'Gentra',
        price: 15000
    },
    {
        name: 'tracker',
        price: 25000
    }
]


let from = prompt('от скольки тысяч ?') // 10000
let to = prompt('до скольки тысяч ?') // 15000


let Avto = moshinBozor.filter( item => item.price >= from && item.price <= to )

console.log(Avto);
// if( from >= +'10000'  && to <= +'15000'  ) {
//    console.log[ price === from && price === to ];
// }

